import importlib
import subprocess
import sys

def ensure_module(module_name, install_name=None):
    """
    Ensures a module is installed. If not, it installs it.
    
    Args:
        module_name (str): The name of the module to import.
        install_name (str): The name to use for installation if different from module_name.
    """
    install_name = install_name or module_name  # Use module_name if install_name not provided
    try:
        importlib.import_module(module_name)
        print(f"'{module_name}' is already installed.")
    except ImportError:
        print(f"'{module_name}' not found. Installing '{install_name}'...")
        if getattr(sys, 'frozen', False):
            print("!ERROR! Cannot install Pillow as in frozen and it was not found !ERROR!")
            input("Enter to exit")
            exit()
        subprocess.check_call([sys.executable, "-m", "pip", "install", install_name])

import tkinter as tk
import argparse
import time
import os
import json
ensure_module("PIL", "pillow")
from PIL import Image, ImageTk

BSOD_MAIN_TEXT = "Your PC ran into a problem and needs to restart. We're just collecting some error info, and then you can restart ({percentage}% complete)"

booting = False
bootInWinre = False

# Define file paths for restore points and system images
restore_points_file = "data/winre/systemrestore/points.array"
system_images_file = "data/winre/systemimages/images.array"

# Function to load data from a file
def load_data_from_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            return json.load(file)  # Load JSON data from file
    return []  # Return an empty list if the file doesn't exist

# Load restore points and system images from files
restore_points = load_data_from_file(restore_points_file)
system_images = load_data_from_file(system_images_file)

# Initialize the response variable
response = None
recovery_window = None
troubleshoot_window = None
# Function to set the response
def set_response(value):
    global response, recovery_window, troubleshoot_window
    response = value
    try:
     troubleshoot_window.destroy()
    except Exception as e:
     print("Could not destory troubleshoot_window: ", e)
    try:
     recovery_window.destroy()
    except Exception as e:
     print("Could not destory recovery_window: ", e)

# Function to show the recovery menu and return the selected response
def show_recovery_menu():
    global recovery_window, response
    recovery_window = tk.Toplevel(root)
    recovery_window.title("Windows Recovery Environment")
    recovery_window.attributes('-fullscreen', True)  # Set to fullscreen
    recovery_window.configure(bg="#1f67b1")  # Set the background color

    # Clear the window
    for widget in recovery_window.winfo_children():
        widget.destroy()

    # Add title label
    title_label = tk.Label(recovery_window, text="Windows Recovery Environment", font=("Arial", 16, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    # Add description label
    description_label = tk.Label(recovery_window, text="Choose an option to continue:", font=("Arial", 12), fg="white", bg="#1f67b1")
    description_label.pack(pady=10)

    # Define button details (image file, command)
    options = [
        ("files/winre/images/buttons/continue.png", lambda: set_response({"type": "continue"})),
        ("files/winre/images/buttons/media.png", lambda: show_drive_selection()),
        ("files/winre/images/buttons/troubleshoot.png", lambda: show_troubleshoot_menu()),
        ("files/winre/images/buttons/off.png", lambda: set_response({"type": "shutdown"}))
    ]

    # Create buttons for each option
    for image_path, command in options:
        image = Image.open(image_path)
        # Resize image to be wide (if necessary, remove if images are already wide)
        image = image.resize((300, 100), Image.Resampling.LANCZOS)  
        photo = ImageTk.PhotoImage(image)

        button = tk.Button(recovery_window, image=photo, command=command, borderwidth=0)
        button.image = photo  # Keep a reference to avoid garbage collection
        button.pack(pady=10)

    # Wait for the response to be set
    recovery_window.wait_window()  # Keep this window open until it is destroyed

    return response  # Return the response once the user has made a selection

# Function to show drive selection
def show_drive_selection():
    drive_selection_window = tk.Toplevel(root)
    drive_selection_window.title("Select a Drive")
    drive_selection_window.attributes('-fullscreen', True)  # Set to fullscreen
    drive_selection_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(drive_selection_window, text="Select a Drive:", font=("Arial", 16, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_drive(drive):
        drive_selection_window.destroy()  # Close the drive selection window
        set_response({"type": "media", "drive": drive})

    # Loop through letters A to Z and create buttons for each letter
    for letter in range(65, 91):  # ASCII values for A-Z
        drive = f"{chr(letter)}:/"
        if os.path.exists(drive):  # Check if the drive exists
            button = tk.Button(drive_selection_window, text=drive, font=("Arial", 12), command=lambda d=drive: select_drive(d))
            button.pack(pady=5)

    back_button = tk.Button(drive_selection_window, text="Back", font=("Arial", 10), command=drive_selection_window.destroy)
    back_button.pack(pady=10)

# Function to show troubleshooting menu
def show_troubleshoot_menu():
    global troubleshoot_window
    troubleshoot_window = tk.Toplevel(root)
    troubleshoot_window.title("Troubleshoot Options")
    troubleshoot_window.attributes('-fullscreen', True)  # Set to fullscreen
    troubleshoot_window.configure(bg="#1f67b1")  # Set the background color

    # Clear the window
    for widget in troubleshoot_window.winfo_children():
        widget.destroy()

    # Load and display the back button image
    back_image_path = "files/winre/images/buttons/back.png"
    back_image = Image.open(back_image_path)
    back_image = back_image.resize((100, 100), Image.Resampling.LANCZOS)  # Resize image to be wide
    back_photo = ImageTk.PhotoImage(back_image)

    back_button = tk.Button(troubleshoot_window, image=back_photo, command=troubleshoot_window.destroy, borderwidth=0)
    back_button.image = back_photo  # Keep a reference to avoid garbage collection
    back_button.pack(pady=10)

    options_label = tk.Label(troubleshoot_window, text="Advanced Options", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    options_label.pack(pady=10)

    # Define advanced option details (image file, command)
    advanced_options = [
        ("files/winre/images/buttons/advanced/systemrestore.png", lambda: show_system_restore()),
        ("files/winre/images/buttons/advanced/commandprompt.png", lambda: open_command_prompt()),
        ("files/winre/images/buttons/advanced/systemimagerecovery.png", lambda: show_system_image_recovery()),
        ("files/winre/images/buttons/advanced/startupsettings.png", lambda: show_error("Error: unable to read startup settings")),
        ("files/winre/images/buttons/advanced/startuprepair.png", lambda: set_response({"type": "startuprepair"})),
        ("files/winre/images/buttons/advanced/previousbuild.png", lambda: show_error("Error: no previous build found or it was deleted."))
    ]

    # Create buttons for each advanced option
    for image_path, command in advanced_options:
        image = Image.open(image_path)
        # Resize image to be wide (if necessary, remove if images are already wide)
        image = image.resize((300, 100), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(image)

        button = tk.Button(troubleshoot_window, image=photo, command=command, borderwidth=0)
        button.image = photo  # Keep a reference to avoid garbage collection
        button.pack(pady=10)

    troubleshoot_window.wait_window()  # Keep this window open until it is destroyed

# Function to launch the command prompt sub-window
def open_command_prompt():
    # Set initial custom directory for this instance to C:/Windows/System32
    custom_directory = "C:/Windows/System32"

    # Create a new Toplevel window as a sub-app
    cmd_window = tk.Toplevel()  # Using tk.Toplevel() instead of directly Toplevel()
    cmd_window.title("Command Prompt")
    cmd_window.geometry("600x400")  # Set to a smaller window size
    cmd_window.configure(bg="black")

    # Command entry field
    command_entry = tk.Entry(cmd_window, font=("Courier", 12), fg="white", bg="black", insertbackground="white")
    command_entry.pack(fill=tk.X, padx=5, pady=5)
    command_entry.bind("<Return>", lambda event: execute_command(command_entry, output_text, custom_directory_var))  # Bind Enter key to run command

    # Output text area
    output_text = tk.Text(cmd_window, font=("Courier", 10), fg="white", bg="black", wrap=tk.WORD)
    output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    output_text.config(state=tk.DISABLED)  # Make the output text widget read-only

    # Create a variable to store the custom directory for this command prompt instance
    custom_directory_var = tk.StringVar(value=os.path.abspath(custom_directory))

    # Show initial prompt
    display_prompt(output_text, custom_directory_var)

# Function to display the command prompt with the current directory path
def display_prompt(output_widget, custom_directory_var):
    output_widget.config(state=tk.NORMAL)
    output_widget.insert(tk.END, f"{custom_directory_var.get()}> ")
    output_widget.config(state=tk.DISABLED)
    output_widget.see(tk.END)  # Scroll to the end

# Function to execute the command entered in the sub-window
def execute_command(entry_widget, output_widget, custom_directory_var):
    command = entry_widget.get()  # Get the command from the entry widget
    entry_widget.delete(0, tk.END)

    output_widget.config(state=tk.NORMAL)
    output_widget.insert(tk.END, f"{command}\n")
    if command.startswith("exitsdbluescreen"):
            root.quit()
            sys.exit()
    try:
        # Handle 'cd' command separately to update custom directory
        if command.startswith("cd"):
            _, path = command.split(" ", 1)
            new_directory = os.path.abspath(os.path.join(custom_directory_var.get(), path))
            if os.path.isdir(new_directory):
                custom_directory_var.set(new_directory)
            else:
                output_widget.insert(tk.END, f"The system cannot find the path specified: {path}\n")
        else:
            # Run the command in a subprocess
            result = subprocess.run(command, shell=True, cwd=custom_directory_var.get(), capture_output=True, text=True)
            output_widget.insert(tk.END, result.stdout if result.stdout else result.stderr)
    except Exception as e:
        output_widget.insert(tk.END, f"Error: {e}\n")

    display_prompt(output_widget, custom_directory_var)  # Show the updated prompt
    output_widget.config(state=tk.DISABLED)
    output_widget.see(tk.END)  # Scroll to the end


# Function to show an error message
def show_error(message):
    error_window = tk.Toplevel(root)
    error_window.title("Error")
    error_window.attributes('-fullscreen', True)  # Set to fullscreen
    error_window.configure(bg="#1f67b1")  # Set the background color

    for widget in error_window.winfo_children():
        widget.destroy()

    error_label = tk.Label(error_window, text=message, font=("Arial", 14), fg="red", bg="#1f67b1")
    error_label.pack(pady=20)

    back_button = tk.Button(error_window, text="Back", font=("Arial", 10), command=error_window.destroy)
    back_button.pack(pady=5)


def show_system_image_recovery():
    restore_window = tk.Toplevel(root)
    restore_window.title("System Image Recovery")
    restore_window.attributes('-fullscreen', True)  # Set to fullscreen
    restore_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(restore_window, text="Select a Imge:", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_restore_point(restore_point):
        # Simulate a restore point usage
        show_error("Error: System image corrupt.")
        restore_window.destroy()

    if not restore_points:
        show_error("No images available.")
    else:
        for point in restore_points:
            button = tk.Button(restore_window, text=point, font=("Arial", 10), command=lambda p=point: select_restore_point(p))
            button.pack(pady=5)

# Function to show system restore points
def show_system_restore():
    restore_window = tk.Toplevel(root)
    restore_window.title("System Restore")
    restore_window.attributes('-fullscreen', True)  # Set to fullscreen
    restore_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(restore_window, text="Select a Restore Point:", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_restore_point(restore_point):
        # Simulate a restore point usage
        show_error("Error: System restore point corrupt.")
        restore_window.destroy()

    if not restore_points:
        show_error("No restore points available.")
    else:
        for point in restore_points:
            button = tk.Button(restore_window, text=point, font=("Arial", 10), command=lambda p=point: select_restore_point(p))
            button.pack(pady=5)

# Function to update progress (simulated via text update)
def update_progress(progress_label, progress_var, time_per_percentage, total_time, infinite):
    progress_var += 1
    progress_label.config(text=f"Collecting data for crash dump... {progress_var}%")

    if progress_var < 100:
        # Make sure time_per_percentage is an integer
        root.after(int(time_per_percentage), update_progress, progress_label, progress_var, time_per_percentage, total_time, infinite)
    elif infinite:
        progress_var = 0  # Reset for infinite loop
        root.after(int(time_per_percentage), update_progress, progress_label, progress_var, time_per_percentage, total_time, infinite)
    else:
        time.sleep(5)
        show_black_screen()
    

def show_black_screen():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.destroy()  # Remove all other widgets from the window
    root.update()
    time.sleep(3)  # Wait for 3 seconds
    show_boot_image()

def show_boot_image():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    booting = True
    boot_image = Image.open('files/win/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot)  # Exit after the GIF finishes

    root.update()

def show_black_screen_startuprepair():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.destroy()  # Remove all other widgets from the window
    root.update()
    time.sleep(3)  # Wait for 3 seconds
    show_startuprepair()

def show_black_screen_off():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.destroy()  # Remove all other widgets from the window
    root.update()

def show_startuprepair():
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/win/startuprepair.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection
    boot_label.after(3000, show_boot_startuprepair)  # Exit after the GIF finishes
    root.update()

def show_boot_startuprepair():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    for widget in root.winfo_children():
        widget.destroy()  # Remove all other widgets from the window
    boot_image = Image.open('files/win/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot_startuprepair)  # Exit after the GIF finishes

    root.update()

def show_black_screen_media():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()

    time.sleep(3)  # Wait for 3 seconds
    show_boot_media()

def show_boot_media():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/win/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot_media)  # Exit after the GIF finishes

    root.update()

def bootwinre():
    winreresp = show_recovery_menu()
    if winreresp["type"] == "startuprepair":
        show_black_screen_startuprepair()
    if winreresp["type"] == "shutdown":
        show_black_screen_off()
    if winreresp["type"] == "media":
        show_black_screen_media()
        

def end_boot():
    global booting, bootInWinre
    booting = False
    if bootInWinre:
        bootInWinre = False
        bootwinre()
    else:
        if args.loop:
            simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)
        else:
            root.quit()

def end_boot_media():
    global booting, bootInWinre
    if bootInWinre:
        bootwinre()
    else:
        root.quit()

def end_boot_startuprepair():
    global booting, bootInWinre
    if bootInWinre:
        bootwinre()
    else:
        if args.looprepair:
            simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)
        else:
            root.quit()
# Main function for simulating BSOD
def simulate_bluescreen(stop_code="SYSTEM_SERVICE_EXCEPTION", driver="tcpip.sys", color="#0041C4", total_time=100, time_per_percentage=100, starting_percentage=0, infinite=False):
    global root
    root = tk.Tk()
    root.attributes('-fullscreen', True)  # Keep fullscreen
    root.configure(background=color)

    # Exit the app on pressing "Esc" key
    root.bind('<Escape>', lambda e: sys.exit())
    root.bind("<F11>", winre_boot)

    # Set the font to 'Lucida Console' and size 12 for everything
    font = ('Lucida Console', 12)

    # Simulate BSOD text with the required information
    stop_code_message = "A problem has been detected and Windows has been shut down to prevent damage to your computer.\n"
    stop_code_message += "If this is the first time you've seen this stop error screen, restart your computer.\n"
    stop_code_message += "If this screen appears again, follow these steps:\n"
    stop_code_message += "Check to make sure any new hardware or software is properly installed.\n"
    stop_code_message += "If this is a new installation, ask your hardware or software manufacturer for any windows updates you might need.\n"
    stop_code_message += "If problems continue, disable or remove any newly installed hardware or software.\n"
    stop_code_message += "Disable BIOS memory options such as caching or shadowing.\n"
    stop_code_message += "If you need to use Safe Mode to remove or disable components, restart your computer, press F8 to select Advanced startup options, and then select Safe Mode.\n"

    technical_info = f"Technical Information:\n\n"
    technical_info += f"*** STOP: 0x00000038 (0x0000000000000005, 0xFFFFF88001A307F8, 0xFFFFF88008CD2C50)\n"
    technical_info += f"*** tcpip.sys Address FFFFF88001A307F8 base at FFFFF88001A03000, Datestamp 4c15a458\n"
    technical_info += "\nCollecting data for crash dump...\n"
    technical_info += "Initializing disk for crash dump...\n"
    technical_info += "Running dump of physical memory...\n"
    technical_info += "Dumping physical memory to disk: 100%\n"
    technical_info += "Memory dump complete.\n"

    # Display the entire BSOD message in one large text box
    text_widget = tk.Text(root, font=font, fg='white', bg=color, wrap='word', bd=0, height=20, width=80)
    text_widget.insert(tk.END, stop_code_message)
    text_widget.insert(tk.END, technical_info)
    text_widget.insert(tk.END, "\nPress ESC to Exit.\n")
    text_widget.config(state=tk.DISABLED)  # Make it read-only
    text_widget.configure(bg=color)  # Set solid background color for the text widget
    text_widget.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    time.sleep(3)

    # Progress text (percentage update)
    progress_var = int(starting_percentage)
    progress_label = tk.Label(root, text=f"Collecting data for crash dump... {progress_var}%", font=font, fg='white', bg=color, anchor='w', justify='left')
    progress_label.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    # Start the progress update based on the total time and time per percentage
    root.after(int(time_per_percentage), update_progress, progress_label, progress_var, time_per_percentage, total_time, infinite)

    # Run the application
    root.mainloop()


def winre_boot(e):
    global bootInWinre, booting
    if booting:
        bootInWinre = True
        print(bootInWinre)

# Argument parser setup
parser = argparse.ArgumentParser(description='Simulate a Windows Blue Screen of Death')
parser.add_argument('-stopcode', type=str, default="INVALID_AFFINITY_SET", help="Custom stop code for the BSOD")
parser.add_argument('-driver', type=str, help="Optional driver name causing the error")
parser.add_argument('-color', type=str, default="#0078d7", help="Background color for the BSOD screen (hex format)")
parser.add_argument('-time', type=float, default=1.0, help="Time in seconds for each percentage increment")
parser.add_argument('-percentage', type=int, default=0, help="Starting progress percentage")
parser.add_argument('-infinite', type=bool, default=False, help="Whether or not the bluescreen is infinite completing")
parser.add_argument('-loop', type=bool, default=False, help="Whether or not it loops forever")
parser.add_argument('-looprepair', type=bool, default=False, help="Can startuprepair fix it?")

# Parse arguments
args = parser.parse_args()

# Call the bluescreen function with provided arguments
simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)