import tkinter as tk
import sys
import argparse
import time
import os
import json
from PIL import Image, ImageTk

booting = False
bootInWinre = False

# Define file paths for restore points and system images
restore_points_file = "data/winre/systemrestore/points.array"
system_images_file = "data/winre/systemimages/images.array"

# Function to load data from a file
def load_data_from_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            return json.load(file)  # Load JSON data from file
    return []  # Return an empty list if the file doesn't exist

# Load restore points and system images from files
restore_points = load_data_from_file(restore_points_file)
system_images = load_data_from_file(system_images_file)

# Initialize the response variable
response = None

# Function to set the response
def set_response(value):
    global response
    response = value

# Function to show the recovery menu and return the selected response
def show_recovery_menu():
    recovery_window = tk.Toplevel(root)
    recovery_window.title("Windows Recovery Environment")
    recovery_window.attributes('-fullscreen', True)  # Set to fullscreen
    recovery_window.configure(bg="#1f67b1")  # Set the background color

    # Clear the window
    for widget in recovery_window.winfo_children():
        widget.destroy()

    # Add title label
    title_label = tk.Label(recovery_window, text="Windows Recovery Environment", font=("Arial", 16, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    # Add description label
    description_label = tk.Label(recovery_window, text="Choose an option to continue:", font=("Arial", 12), fg="white", bg="#1f67b1")
    description_label.pack(pady=10)

    # Define button details (image file, command)
    options = [
        ("files/winre/images/buttons/continue.png", lambda: set_response({"response": "continue"})),
        ("files/winre/images/buttons/media.png", lambda: show_drive_selection()),
        ("files/winre/images/buttons/troubleshoot.png", lambda: show_troubleshoot_menu()),
        ("files/winre/images/buttons/off.png", lambda: set_response({"response": "shutdown"}))
    ]

    # Create buttons for each option
    for image_path, command in options:
        image = Image.open(image_path)
        # Resize image to be wide (if necessary, remove if images are already wide)
        image = image.resize((300, 100), Image.ANTIALIAS)  
        photo = ImageTk.PhotoImage(image)

        button = tk.Button(recovery_window, image=photo, command=command, borderwidth=0)
        button.image = photo  # Keep a reference to avoid garbage collection
        button.pack(pady=10)

    # Wait for the response to be set
    recovery_window.wait_window()  # Keep this window open until it is destroyed

    return response  # Return the response once the user has made a selection

# Function to show drive selection
def show_drive_selection():
    drive_selection_window = tk.Toplevel(root)
    drive_selection_window.title("Select a Drive")
    drive_selection_window.attributes('-fullscreen', True)  # Set to fullscreen
    drive_selection_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(drive_selection_window, text="Select a Drive:", font=("Arial", 16, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_drive(drive):
        show_error(f"You selected drive: {drive}")
        drive_selection_window.destroy()  # Close the drive selection window

    # Loop through letters A to Z and create buttons for each letter
    for letter in range(65, 91):  # ASCII values for A-Z
        drive = f"{chr(letter)}:/"
        if os.path.exists(drive):  # Check if the drive exists
            button = tk.Button(drive_selection_window, text=drive, font=("Arial", 12), command=lambda d=drive: select_drive(d))
            button.pack(pady=5)

    back_button = tk.Button(drive_selection_window, text="Back", font=("Arial", 10), command=drive_selection_window.destroy)
    back_button.pack(pady=10)

# Function to show troubleshooting menu
def show_troubleshoot_menu():
    troubleshoot_window = tk.Toplevel(root)
    troubleshoot_window.title("Troubleshoot Options")
    troubleshoot_window.attributes('-fullscreen', True)  # Set to fullscreen
    troubleshoot_window.configure(bg="#1f67b1")  # Set the background color

    # Clear the window
    for widget in troubleshoot_window.winfo_children():
        widget.destroy()

    title_label = tk.Label(troubleshoot_window, text="Troubleshoot Options", font=("Arial", 16, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    # Load and display the back button image
    back_image_path = "files/winre/images/buttons/back.png"
    back_image = Image.open(back_image_path)
    back_image = back_image.resize((300, 100), Image.ANTIALIAS)  # Resize image to be wide
    back_photo = ImageTk.PhotoImage(back_image)

    back_button = tk.Button(troubleshoot_window, image=back_photo, command=troubleshoot_window.destroy, borderwidth=0)
    back_button.image = back_photo  # Keep a reference to avoid garbage collection
    back_button.pack(pady=10)

    options_label = tk.Label(troubleshoot_window, text="Advanced Options", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    options_label.pack(pady=10)

    # Define advanced option details (image file, command)
    advanced_options = [
        ("files/winre/images/buttons/advanced/systemrestore.png", lambda: show_system_restore()),
        ("files/winre/images/buttons/advanced/commandprompt.png", lambda: open_command_prompt()),
        ("files/winre/images/buttons/advanced/systemimagerecovery.png", lambda: show_system_image_recovery()),
        ("files/winre/images/buttons/advanced/startupsettings.png", lambda: show_error("Error: unable to read startup settings")),
        ("files/winre/images/buttons/advanced/startuprepair.png", lambda: set_response({"type": "startuprepair"})),
        ("files/winre/images/buttons/advanced/previousbuild.png", lambda: show_error("Error: no previous build found or it was deleted."))
    ]

    # Create buttons for each advanced option
    for image_path, command in advanced_options:
        image = Image.open(image_path)
        # Resize image to be wide (if necessary, remove if images are already wide)
        image = image.resize((300, 100), Image.ANTIALIAS)
        photo = ImageTk.PhotoImage(image)

        button = tk.Button(troubleshoot_window, image=photo, command=command, borderwidth=0)
        button.image = photo  # Keep a reference to avoid garbage collection
        button.pack(pady=10)

    troubleshoot_window.wait_window()  # Keep this window open until it is destroyed

def open_command_prompt():
    os.startfile("%windir%/System32/cmd.exe")

# Function to show an error message
def show_error(message):
    error_window = tk.Toplevel(root)
    error_window.title("Error")
    error_window.attributes('-fullscreen', True)  # Set to fullscreen
    error_window.configure(bg="#1f67b1")  # Set the background color

    for widget in error_window.winfo_children():
        widget.destroy()

    error_label = tk.Label(error_window, text=message, font=("Arial", 14), fg="red", bg="#1f67b1")
    error_label.pack(pady=20)

    back_button = tk.Button(error_window, text="Back", font=("Arial", 10), command=error_window.destroy)
    back_button.pack(pady=5)


def show_system_image_recovery():
    restore_window = tk.Toplevel(root)
    restore_window.title("System Image Recovery")
    restore_window.attributes('-fullscreen', True)  # Set to fullscreen
    restore_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(restore_window, text="Select a Imge:", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_restore_point(restore_point):
        # Simulate a restore point usage
        show_error("Error: System image corrupt.")
        restore_window.destroy()

    if not restore_points:
        show_error("No images available.")
    else:
        for point in restore_points:
            button = tk.Button(restore_window, text=point, font=("Arial", 10), command=lambda p=point: select_restore_point(p))
            button.pack(pady=5)

# Function to show system restore points
def show_system_restore():
    restore_window = tk.Toplevel(root)
    restore_window.title("System Restore")
    restore_window.attributes('-fullscreen', True)  # Set to fullscreen
    restore_window.configure(bg="#1f67b1")  # Set the background color

    title_label = tk.Label(restore_window, text="Select a Restore Point:", font=("Arial", 14, "bold"), fg="white", bg="#1f67b1")
    title_label.pack(pady=20)

    def select_restore_point(restore_point):
        # Simulate a restore point usage
        show_error("Error: System restore point corrupt.")
        restore_window.destroy()

    if not restore_points:
        show_error("No restore points available.")
    else:
        for point in restore_points:
            button = tk.Button(restore_window, text=point, font=("Arial", 10), command=lambda p=point: select_restore_point(p))
            button.pack(pady=5)


def update_progress(progress_label, progress_var, time_per_percentage, total_time, infinite, qr_code_label, stop_code_label):
    """Update the progress percentage based on the timer."""
    if infinite:
        while True:
            progress_label.config(text=f"{progress_var}% Complete")  # Update progress label
            progress_label.update()  # Update the label with the new progress
            time.sleep(time_per_percentage)  # Wait for specified time per percentage
    else:
        for i in range(total_time):
            time.sleep(time_per_percentage)  # Wait for specified time per percentage
            progress_var += 1
            progress_label.config(text=f"{progress_var}% Complete")  # Update progress label
            progress_label.update()  # Update the label with the new progress

    show_black_screen()

def show_black_screen():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()
    time.sleep(3)  # Wait for 3 seconds
    show_boot_image()

def show_boot_image():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    booting = True
    boot_image = Image.open('files/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot)  # Exit after the GIF finishes

    root.update()

def show_black_screen_startuprepair():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()
    time.sleep(3)  # Wait for 3 seconds
    show_startuprepair()

def show_black_screen_off():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()

def show_startuprepair():
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/startuprepair.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection
    boot_label.after(3000, show_boot_startuprepair)  # Exit after the GIF finishes
    root.update()

def show_boot_startuprepair():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot_startuprepair)  # Exit after the GIF finishes

    root.update()

def show_black_screen_media():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()

    time.sleep(3)  # Wait for 3 seconds
    show_boot_media()

def show_boot_media():
    global booting
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, end_boot_media)  # Exit after the GIF finishes

    root.update()

def bootwinre():
    winreresp = show_recovery_menu()
    if winreresp["type"] == "startuprepair":
        show_black_screen_startuprepair()
    if winreresp["type"] == "shutdown":
        show_black_screen_off()
    if winreresp["type"] == "media":
        show_black_screen_media()
        

def end_boot():
    global booting, bootInWinre
    booting = False
    if bootInWinre:
        bootInWinre = False
        bootwinre()
    else:
        if args.loop:
            simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)
        else:
            root.quit()

def end_boot_media():
    global booting, bootInWinre
    if bootInWinre:
        bootwinre()
    else:
        root.quit()

def end_boot_startuprepair():
    global booting, bootInWinre
    if bootInWinre:
        bootwinre()
    else:
        if args.looprepair:
            simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)
        else:
            root.quit()

def simulate_bluescreen(stop_code="INVALID_AFFINITY_SET", driver=None, color="#0078d7", total_time=100, time_per_percentage=1, starting_percentage=0, infinite=False, face=":("):
    global root
    root = tk.Tk()
    root.attributes('-fullscreen', True)  # Keep fullscreen
    root.configure(background=color)

    # Exit the app on pressing "Esc" key
    root.bind('<Escape>', lambda e: sys.exit())
    root.bind("<F11>", winre_boot)

    # Display the big sad face at the top, slightly to the right
    sad_face_label = tk.Label(root, text=face, font=('Segoe UI', 180), fg='white', bg=color, anchor='w')
    sad_face_label.pack(anchor='w', padx=(50, 0), pady=(50, 20))

    # Error message text for BSOD
    error_message = f"""
Your PC ran into a problem and needs to restart.
We're just collecting some error info, and then we'll restart for you.
"""
    label = tk.Label(root, text=error_message, font=('Segoe UI', 18), fg='white', bg=color, justify='left', anchor='w')
    label.pack(anchor='w', padx=(50, 0), pady=5)

    # Create a variable to hold the progress percentage
    progress_var = int(starting_percentage)

    # Display the progress percentage
    progress_label = tk.Label(root, text=f"{starting_percentage}% Complete", font=('Segoe UI', 18), fg='white', bg=color, anchor='w')
    progress_label.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    # Create a label for stop code and driver info
    stop_code_message = f"For more information about this issue and possible fixes, visit\nhttps://www.windows.com/stopcode\n\n"
    stop_code_message += f"If you call a support person, give them this info:\nStop code: {stop_code}"

    if driver:
        stop_code_message += f"\nFailed driver: {driver}"

    # Create a frame to hold the QR code and stop code message together
    combined_frame = tk.Frame(root, bg=color)
    combined_frame.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    # Load the QR code image and resize it
    qr_image = Image.open('files/qr.png')  # Load the QR code image
    qr_image = qr_image.resize((150, 150))  # Resize the QR code image (adjust size as needed)
    qr_code_image = ImageTk.PhotoImage(qr_image)  # Create a GifImage object for the QR code

    # Create labels for the QR code and stop code message
    qr_code_label = tk.Label(combined_frame, image=qr_code_image, bg=color)
    qr_code_label.image = qr_code_image  # Keep a reference to prevent garbage collection
    qr_code_label.pack(side='left')  # Pack the QR code label to the left

    # Stop code label
    stop_code_label = tk.Label(combined_frame, text=stop_code_message, font=('Segoe UI', 16), fg='white', bg=color, justify='left')
    stop_code_label.pack(side='left', padx=(20, 0))  # Pack to the left with some space

    # Start the progress update based on the total time and time per percentage
    root.after(1000, update_progress, progress_label, progress_var, time_per_percentage, total_time, infinite, qr_code_label, stop_code_label)

    # Run the application
    root.mainloop()

def winre_boot(e):
    global bootInWinre, booting
    if booting:
        bootInWinre = True
        print(bootInWinre)

# Argument parser setup
parser = argparse.ArgumentParser(description='Simulate a Windows Blue Screen of Death')
parser.add_argument('-stopcode', type=str, default="INVALID_AFFINITY_SET", help="Custom stop code for the BSOD")
parser.add_argument('-driver', type=str, help="Optional driver name causing the error")
parser.add_argument('-color', type=str, default="#0078d7", help="Background color for the BSOD screen (hex format)")
parser.add_argument('-time', type=float, default=1.0, help="Time in seconds for each percentage increment")
parser.add_argument('-percentage', type=int, default=0, help="Starting progress percentage")
parser.add_argument('-infinite', type=bool, default=False, help="Whether or not the bluescreen is infinite completing")
parser.add_argument('-loop', type=bool, default=False, help="Whether or not it loops forever")
parser.add_argument('-looprepair', type=bool, default=False, help="Can startuprepair fix it?")

# Parse arguments
args = parser.parse_args()

# Call the bluescreen function with provided arguments
simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)