import tkinter as tk
import sys
import argparse
import time
from PIL import Image, ImageTk

def update_progress(progress_label, progress_var, time_per_percentage, total_time, infinite, qr_code_label, stop_code_label):
    """Update the progress percentage based on the timer."""
    if infinite:
        while True:
            progress_label.config(text=f"{progress_var}% Complete")  # Update progress label
            progress_label.update()  # Update the label with the new progress
            time.sleep(time_per_percentage)  # Wait for specified time per percentage
    else:
        for i in range(total_time):
            time.sleep(time_per_percentage)  # Wait for specified time per percentage
            progress_var += 1
            progress_label.config(text=f"{progress_var}% Complete")  # Update progress label
            progress_label.update()  # Update the label with the new progress

    show_black_screen()

def show_black_screen():
    """Display a black screen for 3 seconds, then show the boot image."""
    root.configure(background='black')  # Set the background to black
    for widget in root.winfo_children():
        widget.pack_forget()  # Remove all other widgets from the window
    root.update()
    time.sleep(3)  # Wait for 3 seconds
    show_boot_image()

def show_boot_image():
    """Display the boot image and exit the application after 3 seconds."""
    # Create the GifImage object directly from the GIF file
    boot_image = Image.open('files/boot.gif')  # Load the boot image
    gif_image = ImageTk.PhotoImage(boot_image)  # Create a GifImage object

    # Get the screen dimensions for multi-monitor setups
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.geometry(f"{screen_width}x{screen_height}+0+0")  # Set the window size to cover all screens

    # Create a label to display the boot image
    boot_label = tk.Label(root, bg='black')
    boot_label.pack(expand=True, fill='both')  # Fill the whole window

    # Set the GIF image directly to the label
    boot_label.config(image=gif_image)
    boot_label.image = gif_image  # Keep a reference to prevent garbage collection

    # Start the GIF animation
    boot_label.after(3000, root.quit)  # Exit after the GIF finishes

    root.update()

def simulate_bluescreen(stop_code="INVALID_AFFINITY_SET", driver=None, color="#0078d7", total_time=100, time_per_percentage=1, starting_percentage=0, infinite=False):
    global root
    root = tk.Tk()
    root.attributes('-fullscreen', True)  # Keep fullscreen
    root.configure(background=color)

    # Exit the app on pressing "Esc" key
    root.bind('<Escape>', lambda e: sys.exit())

    # Display the big sad face at the top, slightly to the right
    sad_face_label = tk.Label(root, text=":(", font=('Segoe UI', 180), fg='white', bg=color, anchor='w')
    sad_face_label.pack(anchor='w', padx=(50, 0), pady=(50, 20))

    # Error message text for BSOD
    error_message = f"""
Your PC ran into a problem and needs to restart.
We're just collecting some error info, and then we'll restart for you.
"""
    label = tk.Label(root, text=error_message, font=('Segoe UI', 18), fg='white', bg=color, justify='left', anchor='w')
    label.pack(anchor='w', padx=(50, 0), pady=5)

    # Create a variable to hold the progress percentage
    progress_var = int(starting_percentage)

    # Display the progress percentage
    progress_label = tk.Label(root, text=f"{starting_percentage}% Complete", font=('Segoe UI', 18), fg='white', bg=color, anchor='w')
    progress_label.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    # Create a label for stop code and driver info
    stop_code_message = f"For more information about this issue and possible fixes, visit\nhttps://www.windows.com/stopcode\n\n"
    stop_code_message += f"If you call a support person, give them this info:\nStop code: {stop_code}"

    if driver:
        stop_code_message += f"\nFailed driver: {driver}"

    # Create a frame to hold the QR code and stop code message together
    combined_frame = tk.Frame(root, bg=color)
    combined_frame.pack(anchor='w', padx=(50, 0), pady=(0, 20))

    # Load the QR code image and resize it
    qr_image = Image.open('files/qr.png')  # Load the QR code image
    qr_image = qr_image.resize((150, 150))  # Resize the QR code image (adjust size as needed)
    qr_code_image = ImageTk.PhotoImage(qr_image)  # Create a GifImage object for the QR code

    # Create labels for the QR code and stop code message
    qr_code_label = tk.Label(combined_frame, image=qr_code_image, bg=color)
    qr_code_label.image = qr_code_image  # Keep a reference to prevent garbage collection
    qr_code_label.pack(side='left')  # Pack the QR code label to the left

    # Stop code label
    stop_code_label = tk.Label(combined_frame, text=stop_code_message, font=('Segoe UI', 16), fg='white', bg=color, justify='left')
    stop_code_label.pack(side='left', padx=(20, 0))  # Pack to the left with some space

    # Start the progress update based on the total time and time per percentage
    root.after(1000, update_progress, progress_label, progress_var, time_per_percentage, total_time, infinite, qr_code_label, stop_code_label)

    # Run the application
    root.mainloop()

# Argument parser setup
parser = argparse.ArgumentParser(description='Simulate a Windows Blue Screen of Death')
parser.add_argument('-stopcode', type=str, default="INVALID_AFFINITY_SET", help="Custom stop code for the BSOD")
parser.add_argument('-driver', type=str, help="Optional driver name causing the error")
parser.add_argument('-color', type=str, default="#0078d7", help="Background color for the BSOD screen (hex format)")
parser.add_argument('-time', type=float, default=1.0, help="Time in seconds for each percentage increment")
parser.add_argument('-percentage', type=int, default=0, help="Starting progress percentage")
parser.add_argument('-infinite', type=bool, default=False, help="Whether or not the bluescreen is infinite")

# Parse arguments
args = parser.parse_args()

# Call the bluescreen function with provided arguments
simulate_bluescreen(stop_code=args.stopcode, driver=args.driver, color=args.color, total_time=int((100 - args.percentage) * args.time), time_per_percentage=args.time, starting_percentage=args.percentage, infinite=args.infinite)
